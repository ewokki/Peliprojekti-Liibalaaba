﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyAI: MonoBehaviour
{
    public int AIspeed;
    public static int speed;
    private SpriteRenderer spriterenderer;
    // Use this for initialization
    void Start()
    {
        AIspeed = Random.Range(8, 25);
        Debug.Log("speed is" + AIspeed);
        speed = AIspeed;
        spriterenderer = GetComponent<SpriteRenderer>();

    }

    // Update is called once per frame
   void Update()
    {

        if (CameraController.speed < AIspeed)
            transform.position += Vector3.right * Time.deltaTime * AIspeed;
        else if (CameraController.speed > AIspeed)
        {
           
            transform.position += Vector3.right * Time.deltaTime * AIspeed;
        }
            

    }
  
 
}


