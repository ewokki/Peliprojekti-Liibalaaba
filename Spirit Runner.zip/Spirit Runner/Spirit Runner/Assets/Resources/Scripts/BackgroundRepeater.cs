﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BackgroundRepeater : MonoBehaviour {
	private	Transform cameraTransform;
	private	float spriteWidth;
    public GameObject Map;
    public GameObject EndMap;
    public GameObject BlackHole;
    public float delTime;
    public GameObject fRune;
    public GameObject wRune;
    public GameObject vRune;
    public GameObject eRune;
    public GameObject aRune;
    private Vector2 newPos;
    private int i;
    private Vector2 lastplace;
    private Transform spawnPoint;
    public GameObject Enemy;


	// Use this for initialization
	void Start () {
		cameraTransform	=Camera.main.transform; 
		SpriteRenderer	spriteRenderer = GetComponent<Renderer>() as SpriteRenderer;
		spriteWidth	= spriteRenderer.sprite.bounds.size.x; 
		delTime = 7;
        
	}
	
	// Update is called once per frame
	void Update () {
		if(BlackholeArea.isDead == true)
            CancelInvoke("DestroyMe");
        spawnPoint = GameObject.Find("SpawnPoint").transform;
            
      
    }
    void SpawnRunes()
    {
        SpriteRenderer spriteRenderer = GetComponent<Renderer>() as SpriteRenderer;
        int randrune = Random.Range(1, 6);
        Vector2 size = spriteRenderer.sprite.bounds.size;
        Vector2 center = spriteRenderer.sprite.bounds.center;
        Vector2 position = newPos + new Vector2(Random.Range(-size.x / 2, size.x / 2), Random.Range(-size.y / 2, size.y / 2));
        var checkResult = Physics.OverlapSphere(position, 0.5F);
        if (checkResult.Length == 0 && Vector2.Distance(lastplace, position) > 4)
           
        {
            // all clear!

            if (randrune == 1)
            {
                Instantiate(fRune, position, Quaternion.identity);
            }
            else if (randrune == 2)
            {
                Instantiate(wRune, position+newPos, Quaternion.identity);
            }
            else if (randrune == 3)
            {
                Instantiate(aRune, position + newPos, Quaternion.identity);
            }

            else if (randrune == 4)
            {
                Instantiate(vRune, position + newPos, Quaternion.identity);
            }
            else if (randrune == 5)
            {
                Instantiate(eRune, position + newPos, Quaternion.identity);
            }

            lastplace = position;
        }
        else
        {
            i--;
        }
    }
    void SpawnBlackHole()
    {
        SpriteRenderer spriteRenderer = GetComponent<Renderer>() as SpriteRenderer;
        Vector2 size = spriteRenderer.sprite.bounds.size;
        Vector2 position = newPos + new Vector2(Random.Range(-size.x / 2, size.x / 2), Random.Range(-size.y / 3, size.y / 4));
        var checkResult = Physics.OverlapSphere(position, 0.5F);
        Debug.Log(position);
        int randrune = Random.Range(1, 3);
        if (checkResult.Length == 0 && Vector2.Distance(lastplace, position) > 4)
        {
            if (randrune < 2)
            Instantiate(BlackHole, position, Quaternion.identity);
        }
    }
    void SpawnEnemy()
    {
        SpriteRenderer spriteRenderer = GetComponent<Renderer>() as SpriteRenderer;
        
        Vector2 size = spriteRenderer.sprite.bounds.size;
        if (CameraController.speed < EnemyAI.speed)
        {
            Vector2 position = newPos+ new Vector2((-size.x - 15), Random.Range(-size.y / 3, size.y / 4));
            Instantiate(Enemy, position, Quaternion.identity);
        }
        else if (CameraController.speed > EnemyAI.speed)
        {
            Vector2 position = newPos + new Vector2((size.x + 25), Random.Range(-size.y / 3, size.y / 4));
            Instantiate(Enemy, position, Quaternion.identity);
        }
        else
        {
            Debug.Log("FUQ");
        }

    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.gameObject.name == "Player")
        {
            if (BlackholeArea.isDead == false)
            {
                Invoke("DestroyMe", delTime);
            }
        	
            newPos = transform.position;
            newPos.x += 1f * spriteWidth;
            if (Timer.Kello < 20)
            {
                Instantiate(Map, newPos, Quaternion.identity);
                if (Timer.Kello < 10)
                {
                    for (i = 0; i < 1; i++)
                        SpawnBlackHole();
                    for (i = 0; i < 5; i++)
                        SpawnRunes();
                    for (i = 0; i < 1; i++)
                    {
                        Debug.Log("Vihu spawnattu");
                        SpawnEnemy();
                    }
                }
            }
            else
            Instantiate(EndMap, newPos, Quaternion.identity);
        }

    }
    void DestroyMe()
    {
        Destroy(gameObject);
    }

    
 }




