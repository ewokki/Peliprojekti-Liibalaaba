﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Elements : MonoBehaviour {

    public static int Earth, Air, Water, Fire, Void;
	public static float CollectedCurrency;
    public Text EarthT, AirT, WaterT, FireT, VoidT, CollectedCurrencyT;

    private SpriteRenderer PlayerR;
    private Rigidbody2D PlayerRb;

    int max = 0, currentMax;
    List<int> elements = new List<int>();

	// Use this for initialization
	void Start () {
        SaveSystem.Load();

        Prepping.LoadAllData();
        PlayerR = GetComponent<SpriteRenderer>();
        PlayerRb = GetComponent<Rigidbody2D>();
        Prepping.Sprites = Resources.LoadAll<Sprite>("Skins");
        PlayerR.sprite = Prepping.Sprites[Prepping.SkinID];
        PlayerRb.gravityScale = PlayerRb.gravityScale * Prepping.GluttonyModifier;
        Movement.jumpSpeed = (Movement.jumpSpeed * Prepping.GluttonyModifier) * Prepping.JumpStrenghtModifier;
		Debug.Log(Movement.jumpSpeed);
        Debug.Log(PlayerRb.gravityScale);

		Earth = 0;
		Air = 0;
		Water = 0;
		Fire = 0;
		Void = 0;
        CollectedCurrency = 0;
	}
	
	// Update is called once per frame
	void Update () {
        EarthT.text = Earth.ToString();
        AirT.text = Air.ToString();
        WaterT.text = Water.ToString();
        FireT.text = Fire.ToString();
        VoidT.text = Void.ToString();
        CollectedCurrencyT.text = CollectedCurrency.ToString();
	}

    void OnCollisionEnter2D(Collision2D coll)
    {
        if (coll.gameObject.tag == ("Earth"))
        {
            Earth++;
            CollectedCurrency += Prepping.CurrencyModifier;
            Destroy(coll.gameObject);
        }
        if (coll.gameObject.tag == ("Air"))
        {
            Air++;
            CollectedCurrency += Prepping.CurrencyModifier;
            Destroy(coll.gameObject);
        }
        if (coll.gameObject.tag == ("Water"))
        {
            Water++;
            CollectedCurrency += Prepping.CurrencyModifier;
            Destroy(coll.gameObject);
        }
        if (coll.gameObject.tag == ("Fire"))
        {
            Fire++;
            CollectedCurrency += Prepping.CurrencyModifier;
            Destroy(coll.gameObject);
        }
        if (coll.gameObject.tag == ("Void"))
        {
            Void++;
            CollectedCurrency += Prepping.CurrencyModifier;
            Destroy(coll.gameObject);
        }
        elements.Clear();
        elements.Add(Earth);
        elements.Add(Air);
        elements.Add(Water);
        elements.Add(Fire);
        elements.Add(Void);
        currentMax = max;
        GetMax();
        if (max > currentMax)
        {
            for (int i = 0; i < elements.Count; i++)
            {
                if (elements[i] == max)
                {
                    switch (i)
                    {
                        case 0:
                            transform.GetComponent<SpriteRenderer>().color = Color.green;
                            break;
                        case 1:
                            transform.GetComponent<SpriteRenderer>().color = Color.white;
                            break;
                        case 2:
                            transform.GetComponent<SpriteRenderer>().color = Color.blue;
                            break;
                        case 3:
                            transform.GetComponent<SpriteRenderer>().color = Color.red;
                            break;
                        case 4:
                            transform.GetComponent<SpriteRenderer>().color = Color.grey;
                            break;
                    }
                }
            }
        }
        if (elements[0] > 0)
        {
            if (elements[0] == elements[1] && elements[1] == elements[2] && elements[2] == elements[3] && elements[3] == elements[4] && elements[4] == elements[0])
            {
                Vector3 mi = transform.localScale;
                mi.y = 3f;
                mi.x = 3f;
                transform.localScale += mi * (Time.deltaTime*0.5f);
            }
        }


    }

	
	void GetMax()
	{
		foreach(int element in elements)
		{
			if(max < element)
				max = element;
		}
    }
 }

