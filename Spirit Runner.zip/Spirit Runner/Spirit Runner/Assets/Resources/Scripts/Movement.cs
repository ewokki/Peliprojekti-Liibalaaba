﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Movement : MonoBehaviour
{
    public float jumpSpeed = 5f;
    public Rigidbody2D rb;
    private SpriteRenderer playerSprite;

    // Use this for initialization
    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        EndScreenScript.won = false;
        playerSprite = GetComponent<SpriteRenderer>();
        //playerSprite.sprite = Switchsave.Player.sprite;
        
    }

    // Update is called once per frame
    void Update()
    {
        

    }
    void FixedUpdate()
    {
        if (EndScreenScript.won == false)
        {
            transform.position += Vector3.right * Time.deltaTime * CameraController.speed;
            if (Input.GetMouseButton(0))
            {
                rb.AddForce(Vector3.up * jumpSpeed);
            }
        }

    }
}