﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Movement : MonoBehaviour
{
    public static float jumpSpeed;
    public Rigidbody2D rb;
    private SpriteRenderer playerSprite;
    private AudioSource audioSource;
    public AudioClip dmgSound;
    public AudioClip moveSound;


    // Use this for initialization
    void Start()
    {
		jumpSpeed = 50f;
        audioSource = GetComponent<AudioSource>();
        rb = GetComponent<Rigidbody2D>();
        EndScreenScript.won = false;
        
    }

    // Update is called once per frame
    void Update()
    {
        

    }
    void FixedUpdate()
    {
        if (EndScreenScript.won == false)
        {
            transform.position += Vector3.right * Time.deltaTime * CameraController.speed;
            if (Input.GetMouseButton(0))
            {
                rb.AddForce(Vector3.up * jumpSpeed);
            }
        }

    }
}