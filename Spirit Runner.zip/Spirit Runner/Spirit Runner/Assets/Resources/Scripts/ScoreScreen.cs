﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ScoreScreen : MonoBehaviour {
	
	public Text EssenceT, EarthT, AirT, WaterT, FireT, VoidT, CurrencyT;
	// Use this for initialization
	void Start () {
		EarthT.text = Elements.Earth.ToString();
		AirT.text = Elements.Air.ToString();
        WaterT.text = Elements.Water.ToString();
        FireT.text = Elements.Fire.ToString();
        VoidT.text = Elements.Void.ToString();
        CurrencyT.text = Elements.CollectedCurrency.ToString();
        Prepping.Currency += Elements.CollectedCurrency;
        SaveSystem.Save();
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
