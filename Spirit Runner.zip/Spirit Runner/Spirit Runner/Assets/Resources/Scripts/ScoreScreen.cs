﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ScoreScreen : MonoBehaviour {
	
	public Text EssenceT, EarthT, AirT, WaterT, FireT, VoidT;
	// Use this for initialization
	void Start () {
		EarthT.text = Elements.Earth.ToString();
		AirT.text = Elements.Air.ToString();
        WaterT.text = Elements.Water.ToString();
        FireT.text = Elements.Fire.ToString();
        VoidT.text = Elements.Void.ToString();
	}
	
	// Update is called once per frame
	void Update () {
		EarthT.text = Elements.Earth.ToString();
       AirT.text = Elements.Air.ToString();
        WaterT.text = Elements.Water.ToString();
        FireT.text = Elements.Fire.ToString();
        VoidT.text = Elements.Void.ToString();
		
	}
}
