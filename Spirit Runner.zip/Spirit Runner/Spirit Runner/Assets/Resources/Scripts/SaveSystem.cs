﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;
using System.IO;
using SimpleJSON;

public class SaveSystem : MonoBehaviour {

	// Use this for initialization
	void Start () {

	}
	
	// Update is called once per frame
	void Update () {
	
	}

    public static void Save() {
        JSONObject playerJson = new JSONObject();
        playerJson.Add("SkinID", Prepping.SkinID);
        playerJson.Add("Currency", Prepping.Currency);
        Debug.Log(playerJson.ToString());

        string SaveFile = Application.persistentDataPath + "/Saves/PlayerSave.json";
        File.WriteAllText(SaveFile, playerJson.ToString());
    }
    public static void SaveUpgradeData(float Mod, float CostMod, int Lvl, string ModName) {
        JSONObject playerJson = new JSONObject();
        playerJson.Add(ModName, Mod);
        playerJson.Add(ModName + "Cost", CostMod);
        playerJson.Add(ModName + "Lvl", Lvl);
        Debug.Log(playerJson.ToString());
        string SaveFile = Application.persistentDataPath + "/Saves/" + ModName + ".json";
        File.WriteAllText(SaveFile, playerJson.ToString());
    }

    public static void Load() {
        string SaveFile = Application.persistentDataPath + "/Saves/PlayerSave.json";
        string JSONString = File.ReadAllText(SaveFile);
        JSONObject playerJson = (JSONObject)JSON.Parse(JSONString);
        Prepping.SkinID = playerJson["SkinID"];
        Prepping.Currency = playerJson["Currency"];
    }
    public static void LoadUpgradeData(ref float Mod, ref float CostMod, ref int Lvl, string ModName) {
        string SaveFile = Application.persistentDataPath + "/Saves/" + ModName + ".json";
        string JSONString = File.ReadAllText(SaveFile);
        JSONObject playerJson = (JSONObject)JSON.Parse(JSONString);
        Mod = playerJson[ModName];
        CostMod = playerJson[ModName + "Cost"];
        Lvl = playerJson[ModName + "Lvl"];
    }
}
