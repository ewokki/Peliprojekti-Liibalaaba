﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;
using System.IO;
using SimpleJSON;

public class SaveSystem : MonoBehaviour {

	// Use this for initialization
	void Start () {

	}
	
	// Update is called once per frame
	void Update () {
	
	}

    public static void Save() {
        JSONObject playerJson = new JSONObject();
        playerJson.Add("SkinID", Prepping.SkinID);
        playerJson.Add("Currency", Prepping.Currency);
        playerJson.Add("GluttonyMod", Prepping.GluttonyModifier);
        playerJson.Add("JumpMod", Prepping.JumpStrenghtModifier);
        Debug.Log(playerJson.ToString());

        string path = Application.persistentDataPath + "/PlayerSave.json";
        File.WriteAllText(path, playerJson.ToString());
    }

    public static void Load() {
        string path = Application.persistentDataPath + "/PlayerSave.json";
        string JSONString = File.ReadAllText(path);
        JSONObject playerJson = (JSONObject)JSON.Parse(JSONString);
        Prepping.SkinID = playerJson["SkinID"];
        Prepping.Currency = playerJson["Currency"];
        Prepping.GluttonyModifier = playerJson["GluttonyMod"];
        Prepping.JumpStrenghtModifier = playerJson["JumpMod"];
    }
}
