﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class DeathScreen : MonoBehaviour {
	
	public GameObject deathScreen;
	public Button RestartButton ;
	public Button ToMenuButton;
	public AudioClip clickSound;
 	public AudioSource audioSource;
    
 
	// Use this for initialization
void Start()
    {

	deathScreen.SetActive(false);
      RestartButton.onClick.AddListener(Restart);
      ToMenuButton.onClick.AddListener(ToMenu);
      audioSource = GetComponent<AudioSource>();
      
       
      
    }
void Update() {
	
	if (BlackholeArea.isDead == true) {
		deathScreen.SetActive(true);
	}
}

    void Restart()
    {
        Debug.Log("You have clicked the button!");
        audioSource.PlayOneShot(clickSound);
            SceneManager.LoadScene("Game");
            BlackholeArea.isDead = false;
            deathScreen.SetActive(false);
            if (GameObject.Find("Soundplayer") != null)
            {
                Destroy(this.gameObject);
            }
        
    }
    void ToMenu() {
        Debug.Log("You have clicked the button!");
        audioSource.PlayOneShot(clickSound);
            BlackholeArea.isDead = false;
            SceneManager.LoadScene("Prepping");
            if (GameObject.Find("Soundplayer") != null)
            {
                Destroy(this.gameObject);
            }
    	
    }
}
