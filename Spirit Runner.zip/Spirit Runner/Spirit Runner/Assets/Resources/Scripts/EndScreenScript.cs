﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EndScreenScript : MonoBehaviour {
    public static bool won = false;
	private float time;
	private int i = 0;
	// Use this for initialization
	void Start () {
       
	}
	
	// Update is called once per frame
	void Update () {
		if(won)
			time += Time.deltaTime;
			if (time >= 5)
			{
				Application.LoadLevel("ScoreScreen");
			}
	}
    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.gameObject.name == "Player")
        {
           
            Debug.Log("kello on" + Timer.Kello);
            SpriteRenderer spriteRenderer = GetComponent<Renderer>() as SpriteRenderer;
            Vector3 center = spriteRenderer.sprite.bounds.center;
            other.gameObject.transform.position += center * Time.deltaTime;
            won = true;
        }
		
    }
}
