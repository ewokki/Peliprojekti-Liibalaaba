﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerSkin : MonoBehaviour {
    public GameObject Player;
    private SpriteRenderer PlayerR;
	// Use this for initialization
	void Start () {
        PlayerR = Player.GetComponent<SpriteRenderer>();
        Prepping.Sprites = Resources.LoadAll<Sprite>("Skins");
        PlayerR.sprite = Prepping.Sprites[Prepping.SkinID];
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
