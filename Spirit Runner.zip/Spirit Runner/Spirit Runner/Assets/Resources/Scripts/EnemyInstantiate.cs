﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyInstantiate : MonoBehaviour {
    private int rdm_Number;
    public GameObject enemy;
    float time;
	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
        time += Time.deltaTime;
        rdm_Number = 5;
        Debug.Log(rdm_Number);
        if (rdm_Number < time)
        {
            Instantiate(enemy, new Vector2(8, 1), Quaternion.identity);
            time = 0;
        }
		
	}
}
