﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System.IO;

public class Prepping : MonoBehaviour {
	
	public Button NextBtn;
	public Button PreviousBtn;
    public Button JumpSpeedBtn;
    public Button GluttonyBtn;
	public GameObject Player;

	private SpriteRenderer PlayerR;
	public static int SkinID;
	public static Sprite[] Sprites;
	private int NumberOfSprites;
	private int LenghtOfList;

    public static int Currency;
    public Text CurrencyT;

    public static float GluttonyModifier;
    public static float JumpStrenghtModifier;
    public Text JumpStrenghtModifierT;
    public Text GluttonyModifierT;
	
	// Use this for initialization
	void Start () {
        string path = Application.persistentDataPath + "/PlayerSave.json";
        if (!System.IO.File.Exists(path)) 
        {
            SaveSystem.Save();
        }

		NextBtn.onClick.AddListener(Next);
		PreviousBtn.onClick.AddListener(Previous);
        JumpSpeedBtn.onClick.AddListener(UpJump);
        GluttonyBtn.onClick.AddListener(UpGluttony);

		PlayerR = Player.GetComponent<SpriteRenderer>();
		Sprites = Resources.LoadAll<Sprite>("Skins");
		foreach(Sprite sprite in Sprites)
		{
			NumberOfSprites = NumberOfSprites + 1;
		}
		LenghtOfList = NumberOfSprites-1;
        SaveSystem.Load();
        PlayerR.sprite = Sprites[SkinID];
        GluttonyModifier = 1.00f;
        JumpStrenghtModifier = 1.00f;
	}
	
	// Update is called once per frame
	void Update () {
        CurrencyT.text = Currency.ToString();
        JumpStrenghtModifierT.text = JumpStrenghtModifier.ToString();
        GluttonyModifierT.text = GluttonyModifier.ToString();
	}
	void Next(){
		if ((SkinID+1) > LenghtOfList)
		{
			SkinID = 0;
		} else {
			SkinID += 1;
		}
		PlayerR.sprite = Sprites[SkinID];
        SaveSystem.Save();
	}
	void Previous(){
		if ((SkinID-1) < 0)
		{
			SkinID = LenghtOfList;
		} else {
			SkinID -= 1;
		}
		PlayerR.sprite = Sprites[SkinID];
        SaveSystem.Save();
	}
    void UpJump() {
        Currency = Currency - 100;
        JumpStrenghtModifier += 0.10f;
        SaveSystem.Save();
    }
    void UpGluttony() {
        Currency = Currency - 100;
        GluttonyModifier += 0.10f;
        SaveSystem.Save();
    }
}
