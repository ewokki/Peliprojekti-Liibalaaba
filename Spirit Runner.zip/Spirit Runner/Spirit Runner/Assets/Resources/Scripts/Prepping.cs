﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System.IO;

public class Prepping : MonoBehaviour {
	
	public Button NextBtn;
	public Button PreviousBtn;
	public GameObject Player;

	private SpriteRenderer PlayerR;
	public static int SkinID;
	public static Sprite[] Sprites;
	private int NumberOfSprites;
	private int LenghtOfList;

    public static int Currency;
    public Text CurrencyT;

    public static int GluttonyModifier = 1;
    public static float JumpStrenghtModifier = 1;
	
	// Use this for initialization
	void Start () {
        string path = Application.persistentDataPath + "/PlayerSave.json";
        if (!System.IO.File.Exists(path)) 
        {
            SaveSystem.Save();
        }
		NextBtn.onClick.AddListener(Next);
		PreviousBtn.onClick.AddListener(Previous);
		PlayerR = Player.GetComponent<SpriteRenderer>();
		Sprites = Resources.LoadAll<Sprite>("Skins");
		foreach(Sprite sprite in Sprites)
		{
			NumberOfSprites = NumberOfSprites + 1;
		}
		LenghtOfList = NumberOfSprites-1;
        SaveSystem.Load();
        PlayerR.sprite = Sprites[SkinID];
	}
	
	// Update is called once per frame
	void Update () {
        CurrencyT.text = Currency.ToString();
	}
	void Next(){
		if ((SkinID+1) > LenghtOfList)
		{
			SkinID = 0;
		} else {
			SkinID += 1;
		}
		PlayerR.sprite = Sprites[SkinID];
        SaveSystem.Save();
	}
	void Previous(){
		if ((SkinID-1) < 0)
		{
			SkinID = LenghtOfList;
		} else {
			SkinID -= 1;
		}
		PlayerR.sprite = Sprites[SkinID];
        SaveSystem.Save();
	}
}
