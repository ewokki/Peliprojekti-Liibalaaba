﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System.IO;
using System.Linq.Expressions;
using System;

public class Prepping : MonoBehaviour {

    public GameObject Player;

    public Button ResetBtn;
	public Button NextBtn;
	public Button PreviousBtn;
    public Button JumpSpeedBtn;
    public Button GluttonyBtn;
    public Button LifeBtn;
	public Button CurrencyBtn;

	public Text JumpStrenghtModifierT;
    public Text GluttonyModifierT;
	public Text JumpUpgradeCost;
	public Text GluttonyUpgradeCost;
	public Text JumpLevelT;
	public Text GluttonyLevelT;
	public Text CurrencyT;
    public Text LifeModifierT;
    public Text LifeUpgradeCostT;
    public Text LifeLevelT;
	public Text CurrencyModifierT;
	public Text CurrencyUpgradeCost;
	public Text CurrencyLevelT;

	private SpriteRenderer PlayerR;
	public static int SkinID;
	public static Sprite[] Sprites;
	private int NumberOfSprites;
	private int LenghtOfList;

    public static float Currency;

    public static string JumpModName = "JumpMod";
    public static float JumpStrenghtModifier;
	public static float JumpCostModifier;
	public static int JumpLevel;
    private int JumpMaxLevel = 9;

    public static string GluttonyModName = "GluttonyMod";
	public static float GluttonyCostModifier;
	public static float GluttonyModifier;
	public static int GluttonyLevel;
    private int GluttonyMaxLevel = 9;

    public static string LifeModName = "LifeMod";
    public static float LifeCostModifier;
    public static float LifeModifier;
    public static int LifeLevel;
    private int LifeMaxLvl = 4;
	
	public static string CurrencyModName = "CurrencyMod";
	public static float CurrencyCostModifier;
	public static float CurrencyModifier;
	public static int CurrencyLevel;
	private int CurrencyMaxLevel = 17;
	
	private float JumpUpgradeDefaultCost = 50f;
	private float GluttonyUpgradeDefaultCost = 50f;
    private float LifeUpgradeDefaultCost = 250f;
	private float CurrencyUpgradeDefaultCost = 100f;
	
	// Use this for initialization
	void Start () {
        string SaveFolder = Application.persistentDataPath + "/Saves";
		if (!System.IO.Directory.Exists(SaveFolder));
		{
			System.IO.Directory.CreateDirectory(SaveFolder);
		}
        if (!System.IO.File.Exists(SaveFolder + "/PlayerSave.json")) 
        {
            Reset();
        }

		NextBtn.onClick.AddListener(Next);
		PreviousBtn.onClick.AddListener(Previous);
        JumpSpeedBtn.onClick.AddListener(UpJump);
        GluttonyBtn.onClick.AddListener(UpGluttony);
        LifeBtn.onClick.AddListener(UpLife);
		CurrencyBtn.onClick.AddListener(UpCurrency);
        ResetBtn.onClick.AddListener(Reset);

		PlayerR = Player.GetComponent<SpriteRenderer>();
		Sprites = Resources.LoadAll<Sprite>("Skins");
		foreach(Sprite sprite in Sprites)
		{
			NumberOfSprites = NumberOfSprites + 1;
		}
		LenghtOfList = NumberOfSprites-1;
        LoadAllData();
        CheckAllData();
        PlayerR.sprite = Sprites[SkinID];
		
		
	}
	
	// Update is called once per frame
	void Update () {
        CurrencyT.text = Currency.ToString();
	}
	void Next(){
		if ((SkinID+1) > LenghtOfList)
		{
			SkinID = 0;
		} else {
			SkinID += 1;
		}
		PlayerR.sprite = Sprites[SkinID];
        SaveSystem.Save();
	}
	void Previous(){
		if ((SkinID-1) < 0)
		{
			SkinID = LenghtOfList;
		} else {
			SkinID -= 1;
		}
		PlayerR.sprite = Sprites[SkinID];
        SaveSystem.Save();
	}
    void Reset() {
        JumpLevel = 0;
        GluttonyLevel = 0;
        JumpCostModifier = 1.00f;
        JumpStrenghtModifier = 1.00f;
        GluttonyCostModifier = 1.00f;
        GluttonyModifier = 1.00f;
        LifeCostModifier = 1.00f;
        LifeLevel = 0;
        LifeModifier = 1.00f;
		CurrencyCostModifier = 1.00f;
		CurrencyLevel = 0;
		CurrencyModifier = 1.00f;
		Currency = 0f;
        SaveAllData();
        CheckAllData();
    }
    void UpJump() {
        if (JumpLevel <= JumpMaxLevel)
        {
            Upgrade(JumpModName, ref JumpStrenghtModifier, ref JumpCostModifier, ref JumpLevel, JumpUpgradeDefaultCost, 0.10f, 1f);
            CheckAllData();
        }
    }
    void UpGluttony() {
        if (GluttonyLevel <= GluttonyMaxLevel)
        {
            Upgrade(GluttonyModName, ref GluttonyModifier, ref GluttonyCostModifier, ref GluttonyLevel, GluttonyUpgradeDefaultCost, 0.10f, 1f);
            CheckAllData();
        }
    }
    void UpLife() {
        if (LifeLevel <= LifeMaxLvl)
        {
            Upgrade(LifeModName, ref LifeModifier, ref LifeCostModifier, ref LifeLevel, LifeUpgradeDefaultCost, 1f, 1f);
            CheckAllData();
        }
    }
	void UpCurrency(){
		if(CurrencyLevel <= CurrencyMaxLevel){
			Upgrade(CurrencyModName, ref CurrencyModifier, ref CurrencyCostModifier, ref CurrencyLevel, CurrencyUpgradeDefaultCost, 0.50f, 0.50f);
			CheckAllData();
		}
	}
	public static float CheckLevels(int Level, float ModifierIncrease){
		float TotalModifier = (Level + 1) * ModifierIncrease + 1;	//Takes modifier level and modifier increase, then multiplies them 
		return TotalModifier;
	}
	public static float RoundValue(float Value, int DecimalAmount){
		double RoundedValue = System.Math.Round(Value,DecimalAmount);
		return (float)RoundedValue;
	}
    public static string GetMemberName<T>(Expression<Func<T>> memberExpression)
    {
        MemberExpression expressionBody = (MemberExpression)memberExpression.Body;
        return expressionBody.Member.Name;
    }
	void Upgrade(string UpName, ref float Mod, ref float CostMod, ref int Lvl, float UpCost, float ModIncreasePerLevel, float ModPriceIncreasePerLevel){
		if(Currency >= (UpCost*CostMod)){
			Currency = Currency - (UpCost*CostMod);
			Mod = CheckLevels(Lvl, ModIncreasePerLevel);
			CostMod = CheckLevels(Lvl, ModPriceIncreasePerLevel);
			Lvl += 1;
            SaveSystem.SaveUpgradeData(Mod, CostMod, Lvl, UpName);
            SaveSystem.Save();
		} else {
			Debug.Log("NoMoney");
		}
	}
    void CheckData(ref Text ModT, ref Text CostModT, ref Text ModLvlT, float Mod, float CostMod, int ModLvl, float ModDCost, int MaxLvl) {
        ModT.text = (((RoundValue(Mod, 2)) * 100)).ToString() + "%";
        if (ModLvl <= MaxLvl)
        {
            CostModT.text = (ModDCost * CostMod).ToString();
            ModLvlT.text = ModLvl.ToString();
        }
        else {
            CostModT.text = "Infinity";
            ModLvlT.text = "Max";
        }
    }
    public static void LoadAllData()
    {
        SaveSystem.Load();
        SaveSystem.LoadUpgradeData(ref JumpStrenghtModifier, ref JumpCostModifier, ref JumpLevel, JumpModName);
        SaveSystem.LoadUpgradeData(ref GluttonyModifier, ref GluttonyCostModifier, ref GluttonyLevel, GluttonyModName);
        SaveSystem.LoadUpgradeData(ref LifeModifier, ref LifeCostModifier, ref LifeLevel, LifeModName); 
		SaveSystem.LoadUpgradeData(ref CurrencyModifier, ref CurrencyCostModifier, ref CurrencyLevel, CurrencyModName);
    }
    public static void SaveAllData() {
        SaveSystem.Save();
        SaveSystem.SaveUpgradeData(JumpStrenghtModifier, JumpCostModifier, JumpLevel, JumpModName);
        SaveSystem.SaveUpgradeData(GluttonyModifier, GluttonyCostModifier, GluttonyLevel, GluttonyModName);
        SaveSystem.SaveUpgradeData(LifeModifier, LifeCostModifier, LifeLevel, LifeModName);
		SaveSystem.SaveUpgradeData(CurrencyModifier, CurrencyCostModifier, CurrencyLevel, CurrencyModName);
    }
    void CheckAllData() {
        CheckData(ref JumpStrenghtModifierT, ref JumpUpgradeCost, ref JumpLevelT, JumpStrenghtModifier, JumpCostModifier, JumpLevel, JumpUpgradeDefaultCost, JumpMaxLevel);
        CheckData(ref GluttonyModifierT, ref GluttonyUpgradeCost, ref GluttonyLevelT, GluttonyModifier, GluttonyCostModifier, GluttonyLevel, GluttonyUpgradeDefaultCost, GluttonyMaxLevel);
        CheckData(ref LifeModifierT, ref LifeUpgradeCostT, ref LifeLevelT, LifeModifier, LifeCostModifier, LifeLevel, LifeUpgradeDefaultCost, LifeMaxLvl);
		CheckData(ref CurrencyModifierT, ref CurrencyUpgradeCost, ref CurrencyLevelT, CurrencyModifier, CurrencyCostModifier, CurrencyLevel, CurrencyUpgradeDefaultCost, CurrencyMaxLevel);
    }
}
