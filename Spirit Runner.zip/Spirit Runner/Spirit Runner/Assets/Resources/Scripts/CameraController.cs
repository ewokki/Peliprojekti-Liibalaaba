﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraController : MonoBehaviour {
	public static float speed	= 10f;
	private	Vector2	newPosition;
    public GameObject player;
    private Vector2 offset;

	// Use this for initialization
	void Start () {
		newPosition	=	transform.position;
        offset = transform.position - player.transform.position;
	}
	
	// Update is called once per frame
	void Update () {
		
	}
    void FixedUpdate() {
        //newPosition.x += Time.deltaTime * speed;  //10 X-axis units per second
        //transform.position = newPosition;
        transform.position = new Vector3(player.transform.position.x + offset.x, 0, -10);
    }
}
