﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class EssenceCollection : MonoBehaviour {

	private int essence;
	public Text essenceT;
	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		essenceT.text = essence.ToString();
	}
	void OnTriggerEnter2D(Collider2D coll)
    {
        if (coll.gameObject.tag == ("Essence")) 
        {
            essence++;
            Destroy(coll.gameObject);
        }
	}
}
