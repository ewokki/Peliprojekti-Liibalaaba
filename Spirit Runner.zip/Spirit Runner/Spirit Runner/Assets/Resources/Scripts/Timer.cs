﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Timer : MonoBehaviour {
    public static float Kello;

	// Use this for initialization
	void Start () {
		Kello = 0;
	}
	
	// Update is called once per frame
	void Update () {
        Kello += Time.deltaTime;
        
	}
}
