﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Navigation : MonoBehaviour {

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}

    public void LoadCredits() {
        SceneManager.LoadScene("Credits");
    }

    public void LoadInstructions()
    {
        SceneManager.LoadScene("Instructions");
    }

    public void LoadMainManu() {
        SceneManager.LoadScene("MainMenu");
    }

    public void LoadPrepping()
    {
        SceneManager.LoadScene("Prepping");
    }

    public void LoadGame()
    {
        SceneManager.LoadScene("Game");
    }
}
