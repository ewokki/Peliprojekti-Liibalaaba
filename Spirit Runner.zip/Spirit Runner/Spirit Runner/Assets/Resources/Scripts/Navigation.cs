﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Navigation : MonoBehaviour {
    public AudioClip clickSound;
    AudioSource audioSource;
    // Use this for initialization
    void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}

    public void LoadCredits() {
        SceneManager.LoadScene("Credits");
        Debug.Log("You have clicked the button!");
        audioSource.PlayOneShot(clickSound);
    }

    public void LoadInstructions()
    {
        SceneManager.LoadScene("Instructions");
    }

    public void LoadMainManu() {
        SceneManager.LoadScene("MainMenu");
    }

    public void LoadPrepping()
    {
        SceneManager.LoadScene("Prepping");
    }

    public void LoadGame()
    {
        SaveSystem.Save();
        if (GameObject.Find("Soundplayer") != null)
        {
            Destroy(this.gameObject);
        }
        SceneManager.LoadScene("Game");
        
    }
}
