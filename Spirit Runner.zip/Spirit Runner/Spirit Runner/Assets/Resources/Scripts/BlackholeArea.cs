﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BlackholeArea : MonoBehaviour {
   private GameObject PullOBJ;
   public float ForceSpeed = 5.0f;
   public static bool isDead;
 
	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}
    public void OnTriggerStay2D(Collider2D coll)
    {
    	         if (coll.gameObject.tag == ("Player") || coll.gameObject.tag == ("Earth") || coll.gameObject.tag == ("Air") || coll.gameObject.tag == ("Water") || coll.gameObject.tag == ("Fire") || coll.gameObject.tag == ("Void") || coll.gameObject.tag == ("Essence")){
             PullOBJ = coll.gameObject;
 
             PullOBJ.transform.position = Vector3.MoveTowards
                 (PullOBJ.transform.position,
                  transform.position,
                  ForceSpeed * Time.deltaTime);
         } 
        
    }
    void OnTriggerLeave2D(Collider2D coll) {
    	Debug.Log("WROR");
    }
    void OnCollisionEnter2D(Collision2D other)
    {
        if (other.gameObject.tag == ("Player") || other.gameObject.tag == ("Earth") || other.gameObject.tag == ("Air") || other.gameObject.tag == ("Water") || other.gameObject.tag == ("Fire") || other.gameObject.tag == ("Void") || other.gameObject.tag == ("Essence") )
        {
       	    Destroy(other.gameObject);
        }
        if (other.gameObject.name == ("Player"))
        {
        	isDead = true;
        
    }
}

}