﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class SkinSwitch : MonoBehaviour {
	
	public Button NextBtn;
	public Button PreviousBtn;
	public GameObject Player;
	private SpriteRenderer PlayerR;
	private int SkinID;
	private Sprite[] Sprites;
	private int NumberOfSprites;
	private int LenghtOfList;
	
	// Use this for initialization
	void Start () {
		NextBtn.onClick.AddListener(Next);
		PreviousBtn.onClick.AddListener(Previous);
		PlayerR = Player.GetComponent<SpriteRenderer>();
		Sprites = Resources.LoadAll<Sprite>("Skins");
		foreach(Sprite sprite in Sprites)
		{
			NumberOfSprites = NumberOfSprites + 1;
		}
		LenghtOfList = NumberOfSprites-1;
	}
	
	// Update is called once per frame
	void Update () {
		
	}
	void Next(){
		if ((SkinID+1) > LenghtOfList)
		{
			SkinID = 0;
		} else {
			SkinID += 1;
		}
		PlayerR.sprite = Sprites[SkinID];
	}
	void Previous(){
		if ((SkinID-1) < 0)
		{
			SkinID = LenghtOfList;
		} else {
			SkinID -= 1;
		}
		PlayerR.sprite = Sprites[SkinID];
	}
}
