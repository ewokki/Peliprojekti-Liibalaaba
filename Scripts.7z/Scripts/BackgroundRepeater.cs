﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BackgroundRepeater : MonoBehaviour {
	private	Transform cameraTransform;
	private	float spriteWidth;
    public GameObject Map;
    public float delTime;

	// Use this for initialization
	void Start () {
		cameraTransform	=Camera.main.transform; 
		SpriteRenderer	spriteRenderer = GetComponent<Renderer>() as SpriteRenderer;
		spriteWidth	= spriteRenderer.sprite.bounds.size.x; 
	}
	
	// Update is called once per frame
	void Update () {
		
    }
    private void OnTriggerEnter2D(Collider2D other)
    {


        if (other.gameObject.tag == "Player")
        {
            Object.Destroy(gameObject, delTime);
            Vector3 newPos = transform.position;
            newPos.x += 1.01f * spriteWidth;
            Instantiate(Map, newPos, Quaternion.identity);

            







        }

    }

}


