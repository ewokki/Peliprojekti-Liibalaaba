﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class pull : MonoBehaviour {
    public int speed;
     public float pullRadius = 5;
     public float pullForce = 1;
    private Transform pulledObject;
    public Transform magnetpos;
    private Rigidbody2D rb;
   


	// Use this for initialization
	void Start () {
        rb = GetComponent<Rigidbody2D>();

	}
	
	// Update is called once per frame
	void Update () {

        //if (bholearea.totta)
        //{
        //    Vector2 magnetField = magnetpos.position - transform.position;
          //  float index = (pullRadius - magnetField.magnitude) / pullRadius;
           // Debug.Log(magnetField);
            //Debug.Log(index);
            //bholearea.rb.AddForce(pullForce * magnetField * index);
        //}
        //else if (bholearea.totta == false)
        //{
         //   rb.velocity = Vector2.zero;
         //   rb.angularVelocity = 0f; 
        //}
        
	}
   
  

}
