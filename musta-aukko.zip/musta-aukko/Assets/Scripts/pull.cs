﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class pull : MonoBehaviour {
    public int speed;
     public float pullRadius = 5;
     public float pullForce = 1;
     public Rigidbody2D rb;
     public Transform player;
    private bool totta;
 
   


	// Use this for initialization
	void Start () {
        player = GameObject.Find("as").GetComponent<Transform>();

	}
	
	// Update is called once per frame
	void Update () {
        if (totta)
        {

            Vector3 magnetField = transform.position - player.position;
            float index = (pullRadius - magnetField.magnitude) / pullRadius;
            Debug.Log(pullForce);
            Debug.Log(magnetField);
            Debug.Log(index);
            rb.AddForce(pullForce * magnetField * index);
        }
	}
    void OnTriggerEnter2D(Collider2D other)
    {

        totta = true;

    }
    void OnTriggerExit2D(Collider2D other){
        totta = false;
    }
    void OnCollisionEnter2D(Collision2D other)
    {
        Debug.Log("touch");
        Destroy(other.gameObject);
    }

}
